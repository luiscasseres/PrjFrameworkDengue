import fpdf
from fpdf import FPDF
import time

class Relatorio(FPDF):

    def cabecalho(self):
        pdf.image("/home/luis/imagens/Aedes-Aegypti-1.png", 0, 0, 50, 30)
    
    def rodape(self):
        self.set_y(-15)
        self.set_font('Helvetica', 'I', 8)
        self.set_text_color(128)
        self.cell(0, 10, 'Page ' + str(self.page_no()), 0, 0, 'C')
    
    def titulo(self, title, pdf):
    
        pdf.set_font('Helvetica', 'b', 20)  
        pdf.ln(0)
        pdf.write(5, 30*' ' + title)
        pdf.ln(10)

        pdf.set_font('Helvetica', '', 14)
        pdf.set_text_color(r=128,g=128,b=128)
        today = time.strftime("%d/%m/%Y")
        pdf.write(4, 45*' ' + 'Semana Epidemiológica ' +f'{today}')

        pdf.ln(10)

    def escrita(self, pdf, words):

        pdf.set_text_color(r=0,g=0,b=0)
        pdf.set_font('Helvetica', '', 12)

        pdf.write(5, words)
