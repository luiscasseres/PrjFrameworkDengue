## IMPORTAÇÃO DAS DEPENDENCIAS ##

import os 
import xlrd
import fpdf
import math
import time
import datetime
import requests
import gspread
import urllib.parse
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt

from fpdf import FPDF
from matplotlib import rcParams
from simpledbf import Dbf5
from pygal.style import Style
from requests import get
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from IPython.display import SVG, display
from pandas_ods_reader import read_ods
from urllib.request import Request, urlopen

    
## FUNÇÃO PARA CRIAÇÃO DO PROJETO ##

def criarProjeto(prjNome):

	parent_dir = prjNome + "/"

	if os.path.isdir(parent_dir):
		pass
	else:
		os.mkdir(parent_dir) 
	 
	path = os.path.join(parent_dir, "dbf/")

	if os.path.isdir(path):
		pass
	else: 	
		os.mkdir(path) 

	path = os.path.join(parent_dir, "graficos/")   

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 
	
	path = os.path.join(parent_dir, "mapas/") 

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 

	path = os.path.join(parent_dir, "relatorio/") 

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 

	path = os.path.join(parent_dir, "imagens/") 

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 


	print("Projeto '% s' criado!" % parent_dir) 


## CLASSE PARA CRIAÇÃO DO RELATORIO ##

class Relatorio():

	def __init__(self):
		self.pdf = FPDF()			

	def cabecalho(self):
		self.pdf.image("/home/luis/imagens/Aedes-Aegypti-1.png", 0, 0, 50, 30)
    
	def rodape(self):
		self.pdf.set_y(-15)
		self.pdf.set_font('Helvetica', 'I', 8)
		self.pdf.set_text_color(128)
		self.pdf.cell(0, 10, 'Page ' + str(self.pdf.page_no()), 0, 0, 'C')
    
	def titulo(self, title):
		self.pdf.set_font('Helvetica', 'b', 20)
		self.pdf.ln(0)
		self.pdf.write(5, 30*' ' + title)
		self.pdf.ln(10)

		self.pdf.set_font('Helvetica', '', 9)
		self.pdf.set_text_color(r=128,g=128,b=128)
		today = time.strftime("%d/%m/%Y")
		self.pdf.write(4, 67*' ' + 'Semana Epidemiológica ' + f'{today}')

		self.pdf.ln(10)

	def escrita(self, texto, distancia = 4):
		self.pdf.set_text_color(r=0,g=0,b=0)
		self.pdf.set_font('Helvetica', '', 12)

		self.pdf.write(distancia, texto)

	def salva(self, caminho, nome):
		self.pdf.output(caminho + nome + ".pdf", 'F')    

	def adicionaPagina(self):
		self.pdf.add_page()

	def inserirImagem(self, diretorio, tipo):

		if tipo == 'simplificado':

			self.pdf.ln(3)
			self.escrita("Circulação Viral___________________________________________________________________")
			self.pdf.ln(5)

			self.pdf.image(diretorio  + "casosNotificacoes.png", 7, 40, 200, 70)
			self.pdf.ln(5)

			self.pdf.image(diretorio  + "casosAbertos.png", 7, 115, 100, 70)
			self.pdf.ln(5)

			self.pdf.image(diretorio  + "casosSuspeitos.png", 114, 115, 100, 70)
			self.pdf.ln(5)

			self.pdf.ln(140)
			self.escrita("Presença Vetorial_________________________________________________________________")

			self.pdf.image(diretorio  + "Larvas.png", 20, 200, 170, 75)
			self.pdf.ln(5)			


## CLASSE PARA CRIAÇÃO DOS GRÁFICOS ##

class Grafico():

## TRATAMENTO DOS DADOS DA BASE .DBF ##

	def tratamentoDadosDbf(self):

		municipio = ["Candelaria","Gramado Xavier","Herveiras","Mato Leitao","Pantano Grande","Passo do Sobrado","Rio Pardo","Santa Cruz do Sul","Sinimbu","Vale do Sol","Vale Verde","Venancio Aires","Vera Cruz"]
		municipioID = ["430420","430915","430957","431215","431395","431407","431570","431680","432067","432253","432252","432260","432270"]

		for i in range(0,13):

			self.df['ID_MUNICIP']= np.where(((self.df['ID_MUNICIP']==municipioID[i])),municipio[i], self.df['ID_MUNICIP']) 
			self.df['ID_MN_RESI']= np.where(((self.df['ID_MN_RESI']==municipioID[i])),municipio[i], self.df['ID_MN_RESI'])

		self.df['TPAUTOCTO']= np.where(((self.df['TPAUTOCTO']=='1')),'Autoctone', self.df['TPAUTOCTO'])         
		self.df['TPAUTOCTO']= np.where(((self.df['TPAUTOCTO']=='2')),'Importado', self.df['TPAUTOCTO']) 

		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='1')),'Cura', self.df['EVOLUCAO'])         
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='2')),'Obito pelo agravo', self.df['EVOLUCAO'])  
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='3')),'Obito por outras causas', self.df['EVOLUCAO'])         
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='4')),'Obito em investigacao', self.df['EVOLUCAO'])  
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='9')),'Ignorado', self.df['EVOLUCAO'])    

		self.df['NM_BAIRRO'] = self.df['NM_BAIRRO'].str.replace(" ","\n")
		self.df['NM_LOGRADO'] = self.df['NM_LOGRADO'].str.replace(" ","\n")

		self.df['SEM_NOT'] = self.df['SEM_NOT'].str[4:]
		self.df['SEM_PRI'] = self.df['SEM_PRI'].str[4:]
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 4000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 4000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 3000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 3000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 2000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 2000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 1000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 1000) 				  

## CONVERSÃO PARA O FORMATO DE DATA DO EXCEL ##
## FAZ PARTE DO TRATAMENTO DE DADOS DA BASE .XSLX ##

	def xldate_to_datetime(self, xldatetime):

		tempDate = datetime.datetime(1899, 12, 31)
		(days, portion) = math.modf(xldatetime)

		deltaDays = datetime.timedelta(days=days)
		secs = int(24 * 60 * 60 * portion)
		detlaSeconds = datetime.timedelta(seconds=secs)
		TheTime = (tempDate + deltaDays + detlaSeconds)

		return TheTime.strftime("%d-%m-%Y")

## CONVERTE LITERAL PARA INTEIRO ##
## FAZ PARTE DO TRATAMENTO DE DADOS DA BASE .XSLX ##

	def convertLiteralToInt(self, value):
		try:
			number = int(value)
		except ValueError:
			number = 0
		return number	

## TRATAMENTO DE DADOS DA BASE .XSLX ##
## LEITURA DO .XSLX PARA DATAFRAME ##

	def tratamentoDadosXslx(self):
			lista_dados = []

			workbook = xlrd.open_workbook(self.dbfVetor)
			worksheet = workbook.sheet_by_name('RELATORIODENGUE')
			num_rows = worksheet.nrows - 1
			curr_row = 0

			while curr_row < num_rows:
			      if isinstance(worksheet.cell(curr_row, 0).value,float):         
			          
			          lista_dados.append([self.xldate_to_datetime(worksheet.cell(curr_row, 0).value),
			                         worksheet.cell(curr_row, 1).value,
			                         worksheet.cell(curr_row, 2).value,
			                         worksheet.cell(curr_row, 3).value,
			                         self.xldate_to_datetime(worksheet.cell(curr_row, 4).value),
			                         worksheet.cell(curr_row, 5).value,
			                         self.xldate_to_datetime(worksheet.cell(curr_row, 6).value),
			                         worksheet.cell(curr_row, 7).value,
			                         worksheet.cell(curr_row, 8).value,
			                         worksheet.cell(curr_row, 9).value,
			                         self.convertLiteralToInt(worksheet.cell(curr_row, 10).value),
			                         worksheet.cell(curr_row, 11).value,
			                         worksheet.cell(curr_row, 12).value,
			                         worksheet.cell(curr_row, 13).value,
			                         worksheet.cell(curr_row, 14).value,
			                         worksheet.cell(curr_row, 15).value,
			                         worksheet.cell(curr_row, 16).value,
			                         worksheet.cell(curr_row, 17).value,
			                         worksheet.cell(curr_row, 18).value,
			                         worksheet.cell(curr_row, 19).value,
			                         worksheet.cell(curr_row, 20).value,
			                         worksheet.cell(curr_row, 21).value,
			                         worksheet.cell(curr_row, 22).value,
			                         worksheet.cell(curr_row, 23).value,
			                         worksheet.cell(curr_row, 24).value, 
			                         worksheet.cell(curr_row, 25).value, 
			                         worksheet.cell(curr_row, 26).value, 
			                         worksheet.cell(curr_row, 27).value, 
			                         worksheet.cell(curr_row, 28).value, 
			                         worksheet.cell(curr_row, 29).value, 
			                         worksheet.cell(curr_row, 30).value, 
			                         worksheet.cell(curr_row, 31).value, 
			                         worksheet.cell(curr_row, 32).value, 
			                         worksheet.cell(curr_row, 33).value, 
			                         worksheet.cell(curr_row, 34).value, 
			                         worksheet.cell(curr_row, 35).value, 
			                         worksheet.cell(curr_row, 36).value, 
			                         worksheet.cell(curr_row, 37).value, 
			                         worksheet.cell(curr_row, 38).value, 
			                         worksheet.cell(curr_row, 39).value,                     
			                         ])
			      curr_row += 1


			dfSCS=pd.DataFrame(lista_dados,columns=['DATA',                        
			                                     'CRS',
			                                     'MUNICIPIO',
			                                     'LOCALIDADE',
			                                     'DCOLETA',
			                                     'SE',
			                                     'DENTRADA',
			                                     'FIA',
			                                     'NAMOSTRAS',
			                                     'IMOVEISAEAELARVAS',
			                                     'NUMEROAEAELARVAS',
			                                     'IMOVEISAEAEPUPAS',
			                                     'NUMEROAEAEPUPAS',
			                                     'IMOVEISAEAEADULTOS',
			                                     'NUMEROAEAEADULTOS',
			                                     'IMOVEISAEALLARVAS',
			                                     'NUMEROAEALLARVAS',
			                                     'IMOVEISAEALPUPAS',
			                                     'NUMEROAEALPUPAS',
			                                     'IMOVEISAEALADULTOS',
			                                     'NUMEROAEALADULTOS',
			                                     'IMOVEISOULARVAS',
			                                     'NUMEROOULARVAS',
			                                     'IMOVEISOUPUPAS',
			                                     'NUMEROOUPUPAS',
			                                     'IMOVEISOUADULTOS',
			                                     'NUMEROOUADULTOS',
			                                     'IMOVEISANLARVAS',
			                                     'NUMEROANLARVAS',
			                                     'IMOVEISANPUPAS',
			                                     'NUMEROANPUPAS',
			                                     'IMOVEISANADULTOS',
			                                     'NUMEROANADULTOS',
			                                     'IMOVEISNCULILARVAS',
			                                     'NUMERONCULILARVAS',
			                                     'IMOVEISNCULIPUPAS',
			                                     'NUMERONCULIPUPAS',
			                                     'IMOVEISNCULIADULTOS',
			                                     'NUMERONCULIADULTOS',
			                                     'MII'])
			return dfSCS

## INICILIZA A CLASSE GRAFICO ##
## INICILIZA A PERSISITENCIA DO CAMINHO DO DIRETORIO E DA LEITURA DAS BASES DE DADOS ##

	def __init__(self, nomeDiretorio):		

		dbf = Dbf5(os.getcwd() + '/' + nomeDiretorio + '/dbf/Dengue.dbf', codec='cp1250')

		self.dbfVetor = os.getcwd() + '/' + nomeDiretorio + '/dbf/relatoriodengue.xls'
		self.diretorio = os.getcwd() + '/' + nomeDiretorio + '/graficos/'
		self.diretorioRelatorio = os.getcwd() + '/' + nomeDiretorio + '/relatorio/'
		
		self.df = dbf.to_dataframe() 
		self.dfSCS = self.tratamentoDadosXslx()
		self.tratamentoDadosDbf()

		print("Dataframe criado e dados tratados prontos para uso.")
		print("Caso deseje utilizar outro caminho para a base de dados utilize a função [criaConjuntoDados('caminho')].")
		print("O atributo caminho refere-se ao caminho a partir da pasta atual.")

## RETORNA O DATAFRAME REFENRETE AOS DADOS DA BASE .DBF ##

	def getDados():

		return self.df

## CRIA O DATAFRAME A PARTIR DE OUTRO CAMINHO PARA A BASE DE DADOS .DBF QUE NÃO O CAMINHO PADRÃO ##

	def criaConjuntoDados(caminhoDados):

		dbf = Dbf5(caminhoDados + '/Dengue.dbf', codec='cp1250')

		self.df = dbf.to_dataframe() 

## GERA O GRAFICO DOS CASOS SUSPEITOS DE DENGUE. CORRESPONDE AS INVESTIGAÇÕES ABERTAS ##

	def casosSuspeitos(self, xLabel,yLabel,cor='#4169E1', pAlpha=0.5):

		plt.figure(figsize=(9,5))
		sns.set(style="darkgrid")

		try:
			ax = sns.countplot(self.df["ID_MN_RESI"], order = self.df["ID_MN_RESI"].value_counts().index, palette=[cor], alpha = pAlpha)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Suspeitos', fontweight="bold")
			plt.xticks(rotation=45) 
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosSuspeitos.png')  

		except:
			return "Não foi possível plotar gráfico [casosSuspeitos]"

## GERA O GRAFICO DOS CASOS CONFIRMADOS DE DENGUE. CORRESPONDE AS INVESTIGAÇÕES FECHADAS ##

	def casosConfirmados(self, xLabel,yLabel,cor='#4169E1', pAlpha=0.5):

		confirmados = self.df["ID_MN_RESI"]

		plt.figure(figsize=(9,5))
		sns.set(style="darkgrid")

		try:

			ax = sns.countplot(confirmados, order = confirmados.value_counts().index, palette=[cor], alpha = pAlpha)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Confirmados', fontweight="bold")
			plt.xticks(rotation=45) 
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosConfirmados.png')  

		except:

			return "Não foi possível plotar gráfico [casosConfirmados]"

## GERA O GRAFICO DOS CASOS ABERTOS DE DENGUE. INFORMA SOBRE OS CASOS PENDENTES, SEM DEFINIÇÃO E NÃO ENCERRADOS ##

	def casosAbertos(self, xLabel,yLabel,cor='#4169E1', pAlpha=0.5):

		notificacao = self.df[self.df['DT_ENCERRA'].isna()]

		if(len(notificacao) != 0):

			plt.figure(figsize=(9,5))
			sns.set(style="darkgrid")

			try:
				ax = sns.countplot(notificacao["ID_MN_RESI"], order = notificacao["ID_MN_RESI"].value_counts().index, palette=[cor], alpha = pAlpha)
				i=0

				for p in ax.patches:
					height = p.get_height()
					ax.text(p.get_x()+p.get_width()/2., height + 0.2,
					s = '{:.0f}'.format(height),ha="center", color = cor)
					i += 1

				plt.title('Casos Abertos', fontweight="bold")
				plt.xticks(rotation=45) 
				plt.xlabel(xLabel)
				plt.ylabel(yLabel)			
				plt.savefig(self.diretorio + 'casosAbertos.png')  

			except:
				return "Não foi possível plotar gráfico [casosAbertos]"

## GERA O GRAFICO DOS CASOS CONFIRMADOS DE DENGUE POR SEMANA EPIDEMIOLÓGICA. RETRATA A EVOLUÇAO DOS CASOS ##

	def casosConfirmadosSE(self, xLabel,yLabel, cor='#4169E1'):

		confirmadosSE = self.df[self.df['CLASSI_FIN'] == '10']

		dengue = confirmadosSE.sort_values(by='SEM_NOT')

		plt.figure(figsize=(15,5))
		sns.set(style="darkgrid")

		try:      
			ax = sns.histplot(data=dengue, x=dengue['SEM_NOT'], kde=True)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Confirmados SE', fontweight="bold")			
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosConfirmadosSE.png')  

		except:
			return "Não foi possível plotar gráfico [casosConfirmadosSE]"

## GERA O GRAFICO DOS CASOS NOTIFICADOS DE DENGUE. RETRATA AS INVESTIGACOES ABERTAS ##

	def casosNotificacoes(self, xLabel,yLabel, cor='#4169E1', pAlpha=0.5):

		notificacao = self.df.sort_values(by='SEM_NOT')

		plt.figure(figsize=(15,5))
		sns.set(style="darkgrid")

		try:
			ax = sns.histplot(x=notificacao['SEM_NOT'], data=notificacao, palette=[cor], alpha = pAlpha, kde=True)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Notificações', fontweight="bold")			
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosNotificacoes.png')  

		except:
			return "Não foi possível plotar gráfico [casosNotificacoes]"

## GERA O GRAFICO DOS CASOS ABERTOS POR SEMANA EPIDEMIOLOGICA. RETRATA A EVOLUCAO DOS CASOS AINDA NAO ENCERRADOS ##

	def casosAbertosSE(self, xLabel, yLabel, cor='#4169E1', pAlpha=0.5):

		abertosSE = self.df[self.df['DT_ENCERRA'].isna()]

		dengue = abertosSE.sort_values(by='SEM_NOT')

		if (len(dengue) != 0):

			plt.figure(figsize=(15,5))
			sns.set(style="darkgrid")

			try:
				ax = sns.histplot(data=dengue, x=dengue['SEM_NOT'], alpha = pAlpha, kde=True)
				i=0

				for p in ax.patches:
					height = p.get_height()
					ax.text(p.get_x()+p.get_width()/2., height + 0.2,
					s = '{:.0f}'.format(height),ha="center", color = cor)
					i += 1

				plt.title('Casos Abertos SE', fontweight="bold")				
				plt.xlabel(xLabel)
				plt.ylabel(yLabel)			
				plt.savefig(self.diretorio + 'casosAbertosSE.png')  


			except:
				return "Não foi possível plotar gráfico [casosAbertosSE]"

	def Relatorio():
		pass

## RETORNA A LISTAGEM DE LARVAS DO VETOR POR MUNICIPIO. ##

	def listagemMunicipio(self):
		larvas = []

		for municipios in self.dfSCS['MUNICIPIO'].unique().tolist():

			municipio = self.dfSCS[self.dfSCS['MUNICIPIO'] == municipios]

			for ses in municipio['SE'].unique().tolist():

				se = municipio[municipio['SE'] == ses]

				larvas.append([municipios,ses,int(se['NUMEROAEAELARVAS'].sum())])

				dflarvas=pd.DataFrame(larvas,columns=['MUNICIPIO','SE','LARVAS'])

		return dflarvas

## GERA O GRAFICO DA EVOLUCAO DE LARVAS COLETADAS DAS ATIVIDADES DE CAMPO PARA MUNICIPIOS DETERMINADOS. ##

	def larvasMunicipio(self, municipio):

	    dflarvas = self.listagemMunicipio()
	    dfSCS_SCS = dflarvas[dflarvas['MUNICIPIO'] == municipio]

	    fig = plt.figure(figsize=(10,5))
	    sns.set(style="darkgrid")
	    ax = fig.add_axes([0,0,1,1])

	    plt.title('Santa Cruz do Sul', fontweight="bold")
	    plt.ylabel('Qtd Larvas Aedes Aegypti Coletadas')
	    plt.xlabel('Semana Epidemiológica')

	    ax.bar(dfSCS_SCS['SE'],dfSCS_SCS['LARVAS'], alpha=0.5)

	    plt.savefig(self.diretorio + 'Larvas.png', bbox_inches='tight')

## RETORNA A LISTAGEM DAS LARVAS DO VETOR COLETADAS POR MUNICIPIO. ##

	def listagemBairrosMunicipios(self):

	    larvas = []

	    for municipios in self.dfSCS['MUNICIPIO'].unique().tolist():

	      municipio = self.dfSCS[self.dfSCS['MUNICIPIO'] == municipios]

	      for bairros in municipio['LOCALIDADE'].unique().tolist():
	        
	        bairro = municipio[municipio['LOCALIDADE'] == bairros]

	        for ses in bairro['SE'].unique().tolist():

	          se = bairro[bairro['SE'] == ses]

	          larvas.append([municipios, bairros, ses, int(se['NUMEROAEAELARVAS'].sum())])
	          dflarvas=pd.DataFrame(larvas,columns=['MUNICIPIO','BAIRRO','SE','LARVAS'])

	    return dflarvas

## GERA O GRAFICO DA EVOLUCAO DAS LARVAS DO VETOR COLETAS POR BAIRRO PARA MUNCICIPIOS ESPECIFICOS. ##

	def larvasBairros(self, municipio):

	    dflarvas = self.listagemBairrosMunicipios()
	    dfSCS_SCS = dflarvas[dflarvas['MUNICIPIO'] == municipio]

	    for bairro in dfSCS_SCS['BAIRRO'].unique().tolist(): 
	      dfSCS_SCS_BAIRRO = dfSCS_SCS[dfSCS_SCS['BAIRRO'] == bairro]
	      
	      fig = plt.figure(figsize=(10,5))
	      ax = fig.add_axes([0,0,1,1])
	      ax.bar(dfSCS_SCS_BAIRRO['SE'],dfSCS_SCS_BAIRRO['LARVAS'], alpha=0.5)
	      plt.title(bairro + ' :: Santa Cruz do Sul', fontweight="bold")
	      plt.ylabel('Qtd Larvas Aedes Aegypti Coletadas')
	      plt.xlabel('Semana Epidemiológica')
	      plt.savefig(self.diretorio + municipio + '_' + bairro + '_Larvas.png', bbox_inches='tight')

	def relatorio(self, tipo='simplificado', titulo='BOLETIM SIMPLIFICADO'):

		relatorio = Relatorio() 

		relatorio.adicionaPagina()
		relatorio.cabecalho()
		relatorio.titulo("BOLETIM SIMPLIFICADO")
		relatorio.inserirImagem(self.diretorio, tipo)
		relatorio.rodape()
		relatorio.salva(self.diretorioRelatorio, titulo)		
		
		
	      
