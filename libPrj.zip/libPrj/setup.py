from setuptools import find_packages, setup

VERSION = '0.4.1' 
DESCRIPTION = 'PROGRAMA DE POS GRADUCAO EM COMPUTACAO APLICADA - UNISINOS'
LONG_DESCRIPTION = 'TRABALHO FINAL DA DISCIPLINA DE TECNICAS DE PROGRAMACAO'

setup(
    name='frmWrkDengue',
    packages=find_packages(),
    version=VERSION,
    author_email="fcasseres@edu.unisinos.br",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,        
    author='Luis F Casseres',
    license='MIT',
    install_requires=["matplotlib","pandas_ods_reader","requests","seaborn","simpledbf","sklearn","gspread","xlrd","FPDF"]

)

