import os 

import datetime
import requests
import gspread
import urllib.parse
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

from geopy.geocoders import Nominatim
from simpledbf import Dbf5
from pygal.style import Style
from requests import get
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from IPython.display import SVG, display
from pandas_ods_reader import read_ods
from urllib.request import Request, urlopen
    

def criarProjeto(prjNome):

	parent_dir = prjNome + "/"

	if os.path.isdir(parent_dir):
		pass
	else:
		os.mkdir(parent_dir) 
	 
	path = os.path.join(parent_dir, "dbf/")

	if os.path.isdir(path):
		pass
	else: 	
		os.mkdir(path) 

	path = os.path.join(parent_dir, "graficos/")   

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 
	
	path = os.path.join(parent_dir, "mapas/") 

	if os.path.isdir(path):
		pass
	else: 
		os.mkdir(path) 


	print("Projeto '% s' criado!" % parent_dir) 


# CLASSE PARA CRIAÇÃO DOS GRÁFICOS
class Grafico():

	def tratamentoDados(self):

		municipio = ["Candelaria","Gramado Xavier","Herveiras","Mato Leitao","Pantano Grande","Passo do Sobrado","Rio Pardo","Santa Cruz do Sul","Sinimbu","Vale do Sol","Vale Verde","Venancio Aires","Vera Cruz"]
		municipioID = ["430420","430915","430957","431215","431395","431407","431570","431680","432067","432253","432252","432260","432270"]

		for i in range(0,13):

			self.df['ID_MUNICIP']= np.where(((self.df['ID_MUNICIP']==municipioID[i])),municipio[i], self.df['ID_MUNICIP']) 
			self.df['ID_MN_RESI']= np.where(((self.df['ID_MN_RESI']==municipioID[i])),municipio[i], self.df['ID_MN_RESI'])

		self.df['TPAUTOCTO']= np.where(((self.df['TPAUTOCTO']=='1')),'Autoctone', self.df['TPAUTOCTO'])         
		self.df['TPAUTOCTO']= np.where(((self.df['TPAUTOCTO']=='2')),'Importado', self.df['TPAUTOCTO']) 

		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='1')),'Cura', self.df['EVOLUCAO'])         
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='2')),'Obito pelo agravo', self.df['EVOLUCAO'])  
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='3')),'Obito por outras causas', self.df['EVOLUCAO'])         
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='4')),'Obito em investigacao', self.df['EVOLUCAO'])  
		self.df['EVOLUCAO']= np.where(((self.df['EVOLUCAO']=='9')),'Ignorado', self.df['EVOLUCAO'])    

		self.df['NM_BAIRRO'] = self.df['NM_BAIRRO'].str.replace(" ","\n")
		self.df['NM_LOGRADO'] = self.df['NM_LOGRADO'].str.replace(" ","\n")

		self.df['SEM_NOT'] = self.df['SEM_NOT'].str[4:]
		self.df['SEM_PRI'] = self.df['SEM_PRI'].str[4:]
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 4000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 4000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 3000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 3000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 2000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 2000) 
		self.df['NU_IDADE_N']= np.where(((self.df['NU_IDADE_N'].astype(int) - 1000) < 0), self.df['NU_IDADE_N'], self.df['NU_IDADE_N'].astype(int) - 1000) 				  

	def __init__(self, nomeDiretorio):		

		dbf = Dbf5(os.getcwd() + '/' + nomeDiretorio + '/dbf/Dengue.dbf', codec='cp1250')	 

		self.diretorio = os.getcwd() + '/' + nomeDiretorio + '/graficos/'

		self.df = dbf.to_dataframe() 

		self.tratamentoDados()

		print("Dataframe criado e dados tratados prontos para uso.")
		print("Caso deseje utilizar outro caminho para a base de dados utilize a função [criaConjuntoDados('caminho')].")
		print("O atributo caminho refere-se ao caminho a partir da pasta atual.")
	
	def getDados():

		return self.df

	def criaConjuntoDados(caminhoDados):

		dbf = Dbf5('/content/drive/MyDrive/dengue/db_sinan/Dengue.dbf', codec='cp1250')

		self.df = dbf.to_dataframe() 

	def casosSuspeitos(self, xLabel,yLabel,cor='#4169E1', pAlpha=0.5):

		plt.figure(figsize=(9,5))
		sns.set(style="darkgrid")

		try:
			ax = sns.countplot(self.df["ID_MN_RESI"], order = self.df["ID_MN_RESI"].value_counts().index, palette=[cor], alpha = pAlpha)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Suspeitos', fontweight="bold")
			plt.xticks(rotation=45) 
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)
			print(self.diretorio + 'casosSuspeitos.jpeg')
			plt.savefig("/home/luis/Teste/graficos/casosSuspeitos.jpeg")  

		except:
			return "Não foi possível plotar gráfico [casosSuspeitos]"

	def casosConfirmados(self, xLabel,yLabel,cor, pAlpha=0.5):

		confirmados = self.df["ID_MN_RESI"]

		plt.figure(figsize=(9,5))
		sns.set(style="darkgrid")

		try:

			ax = sns.countplot(confirmados, order = confirmados.value_counts().index, palette=[cor], alpha = pAlpha)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Confirmados', fontweight="bold")
			plt.xticks(rotation=45) 
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosConfirmados.jpeg')  

		except:

			return "Não foi possível plotar gráfico [casosConfirmados]"

	def casosAbertos(self, xLabel,yLabel,cor, pAlpha=0.5):

		notificacao = self.df[self.df['DT_ENCERRA'].isna()]

		if(len(notificacao) != 0):

			plt.figure(figsize=(9,5))
			sns.set(style="darkgrid")

			try:
				ax = sns.countplot(notificacao["ID_MN_RESI"], order = notificacao["ID_MN_RESI"].value_counts().index, palette=[cor], alpha = pAlpha)
				i=0

				for p in ax.patches:
					height = p.get_height()
					ax.text(p.get_x()+p.get_width()/2., height + 0.2,
					s = '{:.0f}'.format(height),ha="center", color = cor)
					i += 1

				plt.title('Casos Abertos', fontweight="bold")
				plt.xticks(rotation=45) 
				plt.xlabel(xLabel)
				plt.ylabel(yLabel)			
				plt.savefig(self.diretorio + 'casosAbertos.jpeg')  

			except:
				return "Não foi possível plotar gráfico [casosAbertos]"

	def casosConfirmadosSE(self, xLabel,yLabel, cor):

		confirmadosSE = self.df[self.df['CLASSI_FIN'] == '10']

		dengue = confirmadosSE.sort_values(by='SEM_NOT')

		plt.figure(figsize=(15,5))
		sns.set(style="darkgrid")

		try:      
			ax = sns.histplot(data=dengue, x=dengue['SEM_NOT'], kde=True)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Confirmados SE', fontweight="bold")			
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosConfirmadosSE.jpeg')  

		except:
			return "Não foi possível plotar gráfico [casosConfirmadosSE]"

	def casosNotificacoes(self, xLabel,yLabel, cor, pAlpha=0.5):

		notificacao = self.df.sort_values(by='SEM_NOT')

		plt.figure(figsize=(15,5))
		sns.set(style="darkgrid")

		try:
			ax = sns.histplot(x=notificacao['SEM_NOT'], data=notificacao, palette=[cor], alpha = pAlpha, kde=True)
			i=0

			for p in ax.patches:
				height = p.get_height()
				ax.text(p.get_x()+p.get_width()/2., height + 0.2,
				s = '{:.0f}'.format(height),ha="center", color = cor)
				i += 1

			plt.title('Casos Notificações', fontweight="bold")
			plt.xticks(rotation=45) 
			plt.xlabel(xLabel)
			plt.ylabel(yLabel)			
			plt.savefig(self.diretorio + 'casosNotificacoes.jpeg')  

		except:
			return "Não foi possível plotar gráfico [casosNotificacoes]"

	def casosAbertosSE(self, xLabel,yLabel, cor, pAlpha=0.5):

		abertosSE = self.df[self.df['DT_ENCERRA'].isna()]

		dengue = abertosSE.sort_values(by='SEM_NOT')

		if (len(dengue) != 0):

			plt.figure(figsize=(15,5))
			sns.set(style="darkgrid")

			try:
				ax = sns.histplot(data=dengue, x=dengue['SEM_NOT'], alpha = pAlpha, kde=True)
				i=0

				for p in ax.patches:
					height = p.get_height()
					ax.text(p.get_x()+p.get_width()/2., height + 0.2,
					s = '{:.0f}'.format(height),ha="center", color = cor)
					i += 1

				plt.title('Casos Abertos SE', fontweight="bold")				
				plt.xlabel(xLabel)
				plt.ylabel(yLabel)			
				plt.savefig(self.diretorio + 'casosAbertosSE.jpeg')  


			except:
				return "Não foi possível plotar gráfico [casosAbertosSE]"

	def Relatorio():
		pass
  




