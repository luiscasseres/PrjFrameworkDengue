from setuptools import find_packages, setup

VERSION = '0.8.5' 
DESCRIPTION = 'My first Python package'
LONG_DESCRIPTION = 'My first Python package with a slightly longer description'

setup(
    name='frmWrkDengue',
    packages=find_packages(),
    version=VERSION,
    author_email="<youremail@email.com>",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,        
    author='Luis F Casseres',
    license='MIT',
    install_requires=["matplotlib","pandas_ods_reader","requests","seaborn","simpledbf","sklearn","gspread"]

)

